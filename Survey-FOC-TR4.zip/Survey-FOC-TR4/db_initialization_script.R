
library(DBI)
library(RSQLite)

# connect to database
conn <- dbConnect(RSQLite::SQLite(), "data/sampleIds.db")

tbl_sampleIds <- data.frame(id = character(),
                                 country = character(),
                                 sampleId = character(),
                                 date = character()
                                 )

dbWriteTable(conn, "tbl_sampleIds", tbl_sampleIds, append=T)

dbListTables(conn)
dbDisconnect(conn)

dbRemoveTable(conn,"tbl_sampleIds" )


df1 <- data.frame(country = "Tanzania", number = 3)
df2 <- as.data.frame(df1)[rep(row.names(df1), 3),] %>%
  tibble::rowid_to_column()
df2$id <- df2$rowid + current_id
df2$sampleId <- paste0("IITA_",code,str_pad(df2$id, 5, pad = "0"))
df2$date <- Sys.Date()
df2$rowid <- NULL
df2$number <- NULL
df2
