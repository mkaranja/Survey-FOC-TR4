panel_div <- function(class_type, content) {
    div(class = sprintf("panel panel-%s", class_type),
        div(class = "panel-body", content)
    )
}



shinyUI(fluidPage(
    fluidPage(
        tagList(
            div(style="padding: 1px 0px; width: '100%'",titlePanel(title="", windowTitle = "Survey FOC-TR4")),
            
            useShinyjs(), # Include shinyjs in the UI
            
            tags$style(type = "text/css", ".datepicker{z-index: 1100 !important;}"),
            #shinyjs::inlineCSS(appCSS),
            
            
            navbarPage(title = "SURVEY FOC-TR4",
                       id = "navbar",
                       inverse = TRUE,
                       #selected = "home",
                       theme = "style1.css", 
                       fluid = T,
                       position = "fixed-top",
                       
                       tabPanel(title = "Generate Sample Barcodes", 
                                value = "barcodes",
                                br(),br(),br(),
                                shinyjs::useShinyjs(),
                                shinyjs::extendShinyjs(text = "shinyjs.refresh = function() { location.reload(); }"),
                                
                                fluidRow(
                                    column(3,
                                           panel_div(class_type = "default",
                                                     content = tags$div(
                                                         awesomeRadio("country", "",choices = c("Tanzania", "Vietnam"),
                                                             inline = TRUE, status = "success"), hr(),
                                                         numericInput("number_of_samples", "Number of samples", value=1, min = 1),
                                                         downloadBttn("downloadpdf", "Download", style = "material-flat", siz="xs", color = "success")
                                                         
                                           ))
                                    ),
                                    column(8,
                                           panel_div(class_type = "default",
                                                     content = tags$div(
                                                         DTOutput("sample_barcodes_table")
                                                     ))
                                           )
                                )
                        )
            
                )
            )
    )
))


    
