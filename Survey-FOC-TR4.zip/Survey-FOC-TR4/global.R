library(DBI)
library(RSQLite)
library(DT)

library(magrittr)
library(plyr)
library(dplyr)
library(dbplyr)
library(shinyjs)
library(strex) # extract numbers
library(stringr)
library(qrencoder)
library(shinyWidgets)

sqlitePath <- "data/sampleIds.db"
table <- "tbl_sampleIds"

saveData <- function(data) {
  db <- dbConnect(SQLite(), sqlitePath)
  query <- sprintf(
    "INSERT INTO %s (%s) VALUES ('%s')",
    table, 
    paste(names(data), collapse = ", "),
    paste(data, collapse = "', '")
  )
  dbExecute(db, query)
  dbDisconnect(db)
}

loadData <- function() {
  db <- dbConnect(SQLite(), sqlitePath)
  query <- sprintf("SELECT * FROM %s", table)
  data <- dbGetQuery(db, query)
  dbDisconnect(db)
  data
}

# Define the fields we want to save from the form
fields <- c("id", "country", "sampleId", "date")



